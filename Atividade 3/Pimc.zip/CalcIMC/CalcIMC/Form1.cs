﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcIMC
{
    public partial class Form1 : Form
    {
        double Peso, Altura, Imc;
        public Form1()
        {           
            InitializeComponent();
        }

        private void mskdbxPeso_Click(object sender, EventArgs e)
        {

        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out Altura)|| Altura <= 0)
            {
                MessageBox.Show("Altura Inválida");
                mskbxAltura.Focus();
            }

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
          Close();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            Imc = Peso / Math.Pow(Altura, 2);
            Imc = Math.Round(Imc, 1);
            txtImc.Text = Imc.ToString();
            if (Imc < 18.5)
            {
                MessageBox.Show("Classificacão: Magreza" +
                    " Grau de obesidade: 0");
            }
            else if (Imc <= 24.9)
            {
                MessageBox.Show("Classificação: Normal" +
                    " Grau de obesidade: 0");
            }
            else if(Imc <= 29.9)
            {
                MessageBox.Show("Classificação: Sobrepeso" +
                    " Grau de obesidade: 1");
            }
            else if(Imc <= 39.9)
            {
                MessageBox.Show("Classificação: Obesidade" +
                    " Grau de obesidade: 2");
            }
            else
            {
                MessageBox.Show("Classificação: Obesidade Grave" +
                    " Grau de obesidade: 3");
            }

        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out Peso)|| Peso <=0)
            {
                MessageBox.Show("Peso Inválido");
                mskbxPeso.Focus();
            }

        }
    }
}
