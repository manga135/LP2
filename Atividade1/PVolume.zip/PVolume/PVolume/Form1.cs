﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }



        private void txtbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxAltura.Text, out altura) ||
               (altura <= 0))
            {
                MessageBox.Show("altura inválida");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxAltura.Text, out altura) ||
               (altura <= 0))
            {
                MessageBox.Show("altura inválida");
                txtbxAltura.Focus();
            }

            else if (!double.TryParse(txtbxRaio.Text, out raio) ||
                (raio <= 0))
            {
                MessageBox.Show("raio inválido");
                txtbxRaio.Focus();
            }
            else// calculo
                volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtbxVolume.Text = volume.ToString("N2");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtbxVolume.Clear();
            txtbxRaio.Text = "";
            txtbxAltura.Text = String.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtbxRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxRaio.Text, out raio) || 
                (raio <= 0))
            {
                MessageBox.Show("raio inválido");
            }
            }
        }
    }

