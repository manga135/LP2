﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregado
    {                                                                                  // atributos estão privados
        private int matricula; // atributo com minuscula para diferenciar da propriedade
        private string nomeEmpregado;                                                   
        private DateTime dataEntradaempresa;

        public int Matricula // propriedade com maiusculo para diferenciar do atributo
        {                                                                             // propriedades estão publicas
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
            { 
            get { return nomeEmpregado; } 
            set { nomeEmpregado = value; } 
        }
        
        public DateTime DataEntradaempresa
        {
            get { return dataEntradaempresa; }
            set { dataEntradaempresa = value; }
        }

        public virtual int TempoTrabalho() // método, são açoes e/ou comportamentos
        {                                                                           // virtual pode ser reescrito
            TimeSpan span = DateTime.Today.Subtract(DataEntradaempresa); // TimeSpan representa um intervalo de tempo (datas, horas, semanas,etc)
            return (span.Days);
        }

        public abstract double SalarioBruto();

        public Empregado() //isso é um construtor
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado");
        }
    }
}
