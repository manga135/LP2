﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregado // aqui significa que Mensalista herda (:) as propriedades do Empregado
    {
        public Double SalarioMensal { get; set; }  // para usar o prompt é : prop, tab,tab, e renomear tipo e variavel
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("aqui é mensalista");
        }

        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaempresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Kojima Productions";

    }
}
