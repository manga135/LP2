﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("numero 2 inválido");
                txtNumero2.Focus();
            }
        }

        private void BtnAdicao_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnSubtracao_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnDividisao_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("numero 2 inválido");
                txtNumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
           

        }

        private void Numero1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("numero 1 inválido");
                txtNumero1.Focus();
            }
        }
    }
}
