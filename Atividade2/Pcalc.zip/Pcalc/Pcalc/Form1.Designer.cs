﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNumero1 = new System.Windows.Forms.Label();
            this.LblNumero2 = new System.Windows.Forms.Label();
            this.LblResultado = new System.Windows.Forms.Label();
            this.txtNumero1 = new System.Windows.Forms.TextBox();
            this.txtNumero2 = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.BtnAdicao = new System.Windows.Forms.Button();
            this.BtnSubtracao = new System.Windows.Forms.Button();
            this.BtnMultiplicacao = new System.Windows.Forms.Button();
            this.BtnDividisao = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblNumero1
            // 
            this.LblNumero1.AutoSize = true;
            this.LblNumero1.Location = new System.Drawing.Point(40, 38);
            this.LblNumero1.Name = "LblNumero1";
            this.LblNumero1.Size = new System.Drawing.Size(53, 13);
            this.LblNumero1.TabIndex = 0;
            this.LblNumero1.Text = "Numero 1";
            this.LblNumero1.Click += new System.EventHandler(this.label1_Click);
            // 
            // LblNumero2
            // 
            this.LblNumero2.AutoSize = true;
            this.LblNumero2.Location = new System.Drawing.Point(40, 77);
            this.LblNumero2.Name = "LblNumero2";
            this.LblNumero2.Size = new System.Drawing.Size(53, 13);
            this.LblNumero2.TabIndex = 1;
            this.LblNumero2.Text = "Numero 2";
            this.LblNumero2.Click += new System.EventHandler(this.label2_Click);
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Location = new System.Drawing.Point(40, 186);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(55, 13);
            this.LblResultado.TabIndex = 2;
            this.LblResultado.Text = "Resultado";
            // 
            // txtNumero1
            // 
            this.txtNumero1.Location = new System.Drawing.Point(134, 31);
            this.txtNumero1.Name = "txtNumero1";
            this.txtNumero1.Size = new System.Drawing.Size(304, 20);
            this.txtNumero1.TabIndex = 3;
            this.txtNumero1.Validated += new System.EventHandler(this.Numero1_Validated);
            // 
            // txtNumero2
            // 
            this.txtNumero2.Location = new System.Drawing.Point(134, 74);
            this.txtNumero2.Name = "txtNumero2";
            this.txtNumero2.Size = new System.Drawing.Size(304, 20);
            this.txtNumero2.TabIndex = 4;
            this.txtNumero2.Validated += new System.EventHandler(this.txtNumero2_Validated);
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(134, 183);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(304, 20);
            this.txtResultado.TabIndex = 5;
            // 
            // BtnAdicao
            // 
            this.BtnAdicao.Location = new System.Drawing.Point(134, 308);
            this.BtnAdicao.Name = "BtnAdicao";
            this.BtnAdicao.Size = new System.Drawing.Size(117, 76);
            this.BtnAdicao.TabIndex = 6;
            this.BtnAdicao.Text = "+";
            this.BtnAdicao.UseVisualStyleBackColor = true;
            this.BtnAdicao.Click += new System.EventHandler(this.BtnAdicao_Click);
            // 
            // BtnSubtracao
            // 
            this.BtnSubtracao.Location = new System.Drawing.Point(292, 308);
            this.BtnSubtracao.Name = "BtnSubtracao";
            this.BtnSubtracao.Size = new System.Drawing.Size(119, 76);
            this.BtnSubtracao.TabIndex = 7;
            this.BtnSubtracao.Text = "-";
            this.BtnSubtracao.UseVisualStyleBackColor = true;
            this.BtnSubtracao.Click += new System.EventHandler(this.BtnSubtracao_Click);
            // 
            // BtnMultiplicacao
            // 
            this.BtnMultiplicacao.Location = new System.Drawing.Point(458, 308);
            this.BtnMultiplicacao.Name = "BtnMultiplicacao";
            this.BtnMultiplicacao.Size = new System.Drawing.Size(116, 76);
            this.BtnMultiplicacao.TabIndex = 8;
            this.BtnMultiplicacao.Text = "*";
            this.BtnMultiplicacao.UseVisualStyleBackColor = true;
            this.BtnMultiplicacao.Click += new System.EventHandler(this.BtnMultiplicacao_Click);
            // 
            // BtnDividisao
            // 
            this.BtnDividisao.Location = new System.Drawing.Point(624, 308);
            this.BtnDividisao.Name = "BtnDividisao";
            this.BtnDividisao.Size = new System.Drawing.Size(128, 76);
            this.BtnDividisao.TabIndex = 9;
            this.BtnDividisao.Text = "/";
            this.BtnDividisao.UseVisualStyleBackColor = true;
            this.BtnDividisao.Click += new System.EventHandler(this.BtnDividisao_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(624, 31);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(128, 104);
            this.BtnLimpar.TabIndex = 10;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(624, 141);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(128, 103);
            this.BtnSair.TabIndex = 11;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 686);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnDividisao);
            this.Controls.Add(this.BtnMultiplicacao);
            this.Controls.Add(this.BtnSubtracao);
            this.Controls.Add(this.BtnAdicao);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtNumero2);
            this.Controls.Add(this.txtNumero1);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.LblNumero2);
            this.Controls.Add(this.LblNumero1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNumero1;
        private System.Windows.Forms.Label LblNumero2;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.TextBox txtNumero1;
        private System.Windows.Forms.TextBox txtNumero2;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button BtnAdicao;
        private System.Windows.Forms.Button BtnSubtracao;
        private System.Windows.Forms.Button BtnMultiplicacao;
        private System.Windows.Forms.Button BtnDividisao;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

