﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] vetorNomes = new string[10];

            lbxNomes.Items.Clear();

            for (int i = 0; vetorNomes.Length > i; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome {i + 1} ", "Entrada de Dados");
                if (string.IsNullOrEmpty(auxiliar) || (string.IsNullOrWhiteSpace(auxiliar)))
                {
                    MessageBox.Show("Nome Inválido!");
                    i--;
                }
                else
                vetorNomes[i] = auxiliar;
                auxiliar = vetorNomes[i].Replace(" ", "");

                lbxNomes.Items.Add($"O nome {vetorNomes[i]} tem {auxiliar.Length} caracteres ");
            }

           
        }
    }
}
