﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExerc1 = new System.Windows.Forms.Button();
            this.btnExerc2 = new System.Windows.Forms.Button();
            this.btnExerc3 = new System.Windows.Forms.Button();
            this.btnExerc4 = new System.Windows.Forms.Button();
            this.btnExerc5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExerc1
            // 
            this.btnExerc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExerc1.Location = new System.Drawing.Point(98, 83);
            this.btnExerc1.Name = "btnExerc1";
            this.btnExerc1.Size = new System.Drawing.Size(147, 98);
            this.btnExerc1.TabIndex = 0;
            this.btnExerc1.Text = "Exercicio 1";
            this.btnExerc1.UseVisualStyleBackColor = true;
            this.btnExerc1.Click += new System.EventHandler(this.btnExerc1_Click);
            // 
            // btnExerc2
            // 
            this.btnExerc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExerc2.Location = new System.Drawing.Point(294, 83);
            this.btnExerc2.Name = "btnExerc2";
            this.btnExerc2.Size = new System.Drawing.Size(147, 98);
            this.btnExerc2.TabIndex = 1;
            this.btnExerc2.Text = "Exercicio 2";
            this.btnExerc2.UseVisualStyleBackColor = true;
            this.btnExerc2.Click += new System.EventHandler(this.btnExerc2_Click);
            // 
            // btnExerc3
            // 
            this.btnExerc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExerc3.Location = new System.Drawing.Point(494, 83);
            this.btnExerc3.Name = "btnExerc3";
            this.btnExerc3.Size = new System.Drawing.Size(147, 98);
            this.btnExerc3.TabIndex = 2;
            this.btnExerc3.Text = "Exercicio 3";
            this.btnExerc3.UseVisualStyleBackColor = true;
            this.btnExerc3.Click += new System.EventHandler(this.btnExerc3_Click);
            // 
            // btnExerc4
            // 
            this.btnExerc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExerc4.Location = new System.Drawing.Point(189, 222);
            this.btnExerc4.Name = "btnExerc4";
            this.btnExerc4.Size = new System.Drawing.Size(147, 98);
            this.btnExerc4.TabIndex = 3;
            this.btnExerc4.Text = "Exercicio 4";
            this.btnExerc4.UseVisualStyleBackColor = true;
            this.btnExerc4.Click += new System.EventHandler(this.btnExerc4_Click);
            // 
            // btnExerc5
            // 
            this.btnExerc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExerc5.Location = new System.Drawing.Point(412, 222);
            this.btnExerc5.Name = "btnExerc5";
            this.btnExerc5.Size = new System.Drawing.Size(147, 98);
            this.btnExerc5.TabIndex = 4;
            this.btnExerc5.Text = "Exercicio 5";
            this.btnExerc5.UseVisualStyleBackColor = true;
            this.btnExerc5.Click += new System.EventHandler(this.btnExerc5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExerc5);
            this.Controls.Add(this.btnExerc4);
            this.Controls.Add(this.btnExerc3);
            this.Controls.Add(this.btnExerc2);
            this.Controls.Add(this.btnExerc1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExerc1;
        private System.Windows.Forms.Button btnExerc2;
        private System.Windows.Forms.Button btnExerc3;
        private System.Windows.Forms.Button btnExerc4;
        private System.Windows.Forms.Button btnExerc5;
    }
}

