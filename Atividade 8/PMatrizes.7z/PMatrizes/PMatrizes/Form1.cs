﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Net.Http.Headers;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExerc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o número {i +1} ", "Entrada de Dados");

                /*
                if (auxiliar == "")
                {
                    break;
                }
                */
               
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int j in vetor)
            {
                auxiliar += j + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExerc2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camilla", 
                "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Otávio");
            string resultado = string.Join("\n", lista.ToArray());

            MessageBox.Show(resultado);


        }

        private void btnExerc3_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[20, 3];
            string auxiliar2;
            string resultado = "";
            


            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar2 = Interaction.InputBox($"Digite a nota {nota +1} do aluno", "Entrada de Dados");

                  
                    if (auxiliar2 == "")
                    {
                        MessageBox.Show("Entrada de nota não pode ser vazia, digite um valor entre 0 e 10");
                        continue;
                    }

                    if (!double.TryParse(auxiliar2, out vetor[aluno, nota]) || vetor[aluno, nota] < 0 || vetor[aluno, nota] > 10)
                    {
                        MessageBox.Show("Nota inválida, digite um valor numérico entre 0 e 10");
                        nota--;
                    }
                
                }

            }
            for (int aluno = 0; aluno < 20; aluno++)
            {
                double soma = 0;

                for (int nota = 0; nota < 3; nota++)
                {
                    soma += vetor[aluno, nota];
                }
                double media = soma / 3;
                resultado += $"aluno {aluno + 1}, média: {media.ToString("F2")}\n ";
            }
            MessageBox.Show(resultado,"Médias dos alunos");




        }

        private void btnExerc4_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }
    }
}
