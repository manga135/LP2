﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;
using System.Runtime.Serialization;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[3, 3];
            string auxiliar;
            string total = "";

                for (int note = 0; note < 3; note++)
            
                for (int loja = 0; loja < 3; loja++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor do Notebook {note + 1} da loja {loja + 1}");
                    lbxNotebook.Items.Add($"Notebook {note +1} Loja {loja +1} {auxiliar}");
                    

                    if (auxiliar == "")
                    {
                        MessageBox.Show("Entrada de valor não pode ser vazia, digite um valor numérico maior ou igual a zero");
                        continue;
                    }
                    if (!double.TryParse(auxiliar, out vetor[note, loja]) || vetor[note, loja] <= 0 )
                    {
                        MessageBox.Show("Valor inválido, digite um valor numérico maior ou igual a zero");
                        note--;
                    }
                }

            for (int note = 0; note < 3;note++)
            {
                double somaNotes = 0;
                double somaTotal = 0;
                for (int loja = 0; loja < 3; loja++)
                {
                    somaNotes += vetor[note, loja];
                   
                }
                double media = somaNotes / 3;
                total += $"Notebook {note + 1}, média: {media.ToString("C2")}\n ";
                lbxNotebook.Items.Add($"{total}");


            }
               
            }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxNotebook.Items.Clear();
        }
    }
    }

