﻿namespace PFerramenta0030482421008
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatheus = new System.Windows.Forms.Label();
            this.lblCarol = new System.Windows.Forms.Label();
            this.lblRA2 = new System.Windows.Forms.Label();
            this.lblRA1 = new System.Windows.Forms.Label();
            this.lblRA = new System.Windows.Forms.Label();
            this.pbSableye = new System.Windows.Forms.PictureBox();
            this.lblClasses2 = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblClasses = new System.Windows.Forms.Label();
            this.lblLP = new System.Windows.Forms.Label();
            this.lblClasses3 = new System.Windows.Forms.Label();
            this.lblClasses1 = new System.Windows.Forms.Label();
            this.lblCsharp = new System.Windows.Forms.Label();
            this.lblV1 = new System.Windows.Forms.Label();
            this.lblVersao = new System.Windows.Forms.Label();
            this.lblCopyright = new System.Windows.Forms.Label();
            this.lblNomeApp = new System.Windows.Forms.Label();
            this.pbTurtwig = new System.Windows.Forms.PictureBox();
            this.lblEmpresa = new System.Windows.Forms.Label();
            this.lblArasaka = new System.Windows.Forms.Label();
            this.lblIntuito = new System.Windows.Forms.Label();
            this.lblExplicacao = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbSableye)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTurtwig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(22, 62);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(221, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome dos Programadores:";
            // 
            // lblMatheus
            // 
            this.lblMatheus.AutoSize = true;
            this.lblMatheus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatheus.Location = new System.Drawing.Point(249, 62);
            this.lblMatheus.Name = "lblMatheus";
            this.lblMatheus.Size = new System.Drawing.Size(261, 20);
            this.lblMatheus.TabIndex = 1;
            this.lblMatheus.Text = "Matheus Henrique Roque Camargo";
            // 
            // lblCarol
            // 
            this.lblCarol.AutoSize = true;
            this.lblCarol.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarol.Location = new System.Drawing.Point(567, 62);
            this.lblCarol.Name = "lblCarol";
            this.lblCarol.Size = new System.Drawing.Size(184, 20);
            this.lblCarol.TabIndex = 2;
            this.lblCarol.Text = "Caroline Espanha Simão";
            // 
            // lblRA2
            // 
            this.lblRA2.AutoSize = true;
            this.lblRA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA2.Location = new System.Drawing.Point(567, 102);
            this.lblRA2.Name = "lblRA2";
            this.lblRA2.Size = new System.Drawing.Size(126, 20);
            this.lblRA2.TabIndex = 3;
            this.lblRA2.Text = "0030482421028";
            // 
            // lblRA1
            // 
            this.lblRA1.AutoSize = true;
            this.lblRA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA1.Location = new System.Drawing.Point(249, 102);
            this.lblRA1.Name = "lblRA1";
            this.lblRA1.Size = new System.Drawing.Size(126, 20);
            this.lblRA1.TabIndex = 4;
            this.lblRA1.Text = "0030482421008";
            // 
            // lblRA
            // 
            this.lblRA.AutoSize = true;
            this.lblRA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA.Location = new System.Drawing.Point(22, 102);
            this.lblRA.Name = "lblRA";
            this.lblRA.Size = new System.Drawing.Size(39, 20);
            this.lblRA.TabIndex = 5;
            this.lblRA.Text = "RA:";
            // 
            // pbSableye
            // 
            this.pbSableye.Image = ((System.Drawing.Image)(resources.GetObject("pbSableye.Image")));
            this.pbSableye.Location = new System.Drawing.Point(270, 125);
            this.pbSableye.Name = "pbSableye";
            this.pbSableye.Size = new System.Drawing.Size(95, 81);
            this.pbSableye.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSableye.TabIndex = 6;
            this.pbSableye.TabStop = false;
            // 
            // lblClasses2
            // 
            this.lblClasses2.AutoSize = true;
            this.lblClasses2.BackColor = System.Drawing.Color.White;
            this.lblClasses2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasses2.Location = new System.Drawing.Point(34, 297);
            this.lblClasses2.Name = "lblClasses2";
            this.lblClasses2.Size = new System.Drawing.Size(66, 16);
            this.lblClasses2.TabIndex = 7;
            this.lblClasses2.Text = "Categoria";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.BackColor = System.Drawing.Color.White;
            this.lblInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(24, 229);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(225, 16);
            this.lblInfo.TabIndex = 8;
            this.lblInfo.Text = "Informações Sobre a Aplicação";
            // 
            // lblClasses
            // 
            this.lblClasses.AutoSize = true;
            this.lblClasses.BackColor = System.Drawing.Color.White;
            this.lblClasses.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasses.Location = new System.Drawing.Point(34, 255);
            this.lblClasses.Name = "lblClasses";
            this.lblClasses.Size = new System.Drawing.Size(66, 18);
            this.lblClasses.TabIndex = 9;
            this.lblClasses.Text = "Classes:";
            // 
            // lblLP
            // 
            this.lblLP.AutoSize = true;
            this.lblLP.BackColor = System.Drawing.Color.White;
            this.lblLP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLP.Location = new System.Drawing.Point(191, 257);
            this.lblLP.Name = "lblLP";
            this.lblLP.Size = new System.Drawing.Size(254, 18);
            this.lblLP.TabIndex = 10;
            this.lblLP.Text = "Linguagem de programação utilizada:";
            // 
            // lblClasses3
            // 
            this.lblClasses3.AutoSize = true;
            this.lblClasses3.BackColor = System.Drawing.Color.White;
            this.lblClasses3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasses3.Location = new System.Drawing.Point(34, 313);
            this.lblClasses3.Name = "lblClasses3";
            this.lblClasses3.Size = new System.Drawing.Size(71, 16);
            this.lblClasses3.TabIndex = 11;
            this.lblClasses3.Text = "Fabricante";
            // 
            // lblClasses1
            // 
            this.lblClasses1.AutoSize = true;
            this.lblClasses1.BackColor = System.Drawing.Color.White;
            this.lblClasses1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClasses1.Location = new System.Drawing.Point(34, 281);
            this.lblClasses1.Name = "lblClasses1";
            this.lblClasses1.Size = new System.Drawing.Size(83, 16);
            this.lblClasses1.TabIndex = 12;
            this.lblClasses1.Text = "Ferramentas";
            // 
            // lblCsharp
            // 
            this.lblCsharp.AutoSize = true;
            this.lblCsharp.BackColor = System.Drawing.Color.White;
            this.lblCsharp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCsharp.Location = new System.Drawing.Point(191, 281);
            this.lblCsharp.Name = "lblCsharp";
            this.lblCsharp.Size = new System.Drawing.Size(23, 16);
            this.lblCsharp.TabIndex = 13;
            this.lblCsharp.Text = "C#";
            // 
            // lblV1
            // 
            this.lblV1.AutoSize = true;
            this.lblV1.BackColor = System.Drawing.Color.White;
            this.lblV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV1.Location = new System.Drawing.Point(34, 379);
            this.lblV1.Name = "lblV1";
            this.lblV1.Size = new System.Drawing.Size(33, 16);
            this.lblV1.TabIndex = 14;
            this.lblV1.Text = "V1.0";
            // 
            // lblVersao
            // 
            this.lblVersao.AutoSize = true;
            this.lblVersao.BackColor = System.Drawing.Color.White;
            this.lblVersao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersao.Location = new System.Drawing.Point(34, 349);
            this.lblVersao.Name = "lblVersao";
            this.lblVersao.Size = new System.Drawing.Size(146, 18);
            this.lblVersao.TabIndex = 15;
            this.lblVersao.Text = "Versão da aplicação:";
            // 
            // lblCopyright
            // 
            this.lblCopyright.AutoSize = true;
            this.lblCopyright.Location = new System.Drawing.Point(652, 420);
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(125, 13);
            this.lblCopyright.TabIndex = 16;
            this.lblCopyright.Text = "Copyright © Arasaka inc.";
            // 
            // lblNomeApp
            // 
            this.lblNomeApp.AutoSize = true;
            this.lblNomeApp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeApp.Location = new System.Drawing.Point(27, 13);
            this.lblNomeApp.Name = "lblNomeApp";
            this.lblNomeApp.Size = new System.Drawing.Size(105, 24);
            this.lblNomeApp.TabIndex = 17;
            this.lblNomeApp.Text = "Delta V1.0";
            // 
            // pbTurtwig
            // 
            this.pbTurtwig.Image = ((System.Drawing.Image)(resources.GetObject("pbTurtwig.Image")));
            this.pbTurtwig.Location = new System.Drawing.Point(597, 125);
            this.pbTurtwig.Name = "pbTurtwig";
            this.pbTurtwig.Size = new System.Drawing.Size(96, 81);
            this.pbTurtwig.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTurtwig.TabIndex = 18;
            this.pbTurtwig.TabStop = false;
            // 
            // lblEmpresa
            // 
            this.lblEmpresa.AutoSize = true;
            this.lblEmpresa.BackColor = System.Drawing.Color.White;
            this.lblEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpresa.Location = new System.Drawing.Point(476, 257);
            this.lblEmpresa.Name = "lblEmpresa";
            this.lblEmpresa.Size = new System.Drawing.Size(135, 18);
            this.lblEmpresa.TabIndex = 19;
            this.lblEmpresa.Text = "Nome da empresa:";
            // 
            // lblArasaka
            // 
            this.lblArasaka.AutoSize = true;
            this.lblArasaka.BackColor = System.Drawing.Color.White;
            this.lblArasaka.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArasaka.Location = new System.Drawing.Point(476, 281);
            this.lblArasaka.Name = "lblArasaka";
            this.lblArasaka.Size = new System.Drawing.Size(62, 18);
            this.lblArasaka.TabIndex = 20;
            this.lblArasaka.Text = "Arasaka";
            // 
            // lblIntuito
            // 
            this.lblIntuito.AutoSize = true;
            this.lblIntuito.BackColor = System.Drawing.Color.White;
            this.lblIntuito.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntuito.Location = new System.Drawing.Point(191, 349);
            this.lblIntuito.Name = "lblIntuito";
            this.lblIntuito.Size = new System.Drawing.Size(138, 18);
            this.lblIntuito.TabIndex = 21;
            this.lblIntuito.Text = "Intuito da aplicação:";
            // 
            // lblExplicacao
            // 
            this.lblExplicacao.AutoSize = true;
            this.lblExplicacao.BackColor = System.Drawing.Color.White;
            this.lblExplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExplicacao.Location = new System.Drawing.Point(191, 379);
            this.lblExplicacao.Name = "lblExplicacao";
            this.lblExplicacao.Size = new System.Drawing.Size(285, 36);
            this.lblExplicacao.TabIndex = 22;
            this.lblExplicacao.Text = "Permitir edição de tabelas com integração\r\n de um banco de dados SQL";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Location = new System.Drawing.Point(17, 221);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(629, 212);
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblExplicacao);
            this.Controls.Add(this.lblIntuito);
            this.Controls.Add(this.lblArasaka);
            this.Controls.Add(this.lblEmpresa);
            this.Controls.Add(this.pbTurtwig);
            this.Controls.Add(this.lblNomeApp);
            this.Controls.Add(this.lblCopyright);
            this.Controls.Add(this.lblVersao);
            this.Controls.Add(this.lblV1);
            this.Controls.Add(this.lblCsharp);
            this.Controls.Add(this.lblClasses1);
            this.Controls.Add(this.lblClasses3);
            this.Controls.Add(this.lblLP);
            this.Controls.Add(this.lblClasses);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblClasses2);
            this.Controls.Add(this.pbSableye);
            this.Controls.Add(this.lblRA);
            this.Controls.Add(this.lblRA1);
            this.Controls.Add(this.lblRA2);
            this.Controls.Add(this.lblCarol);
            this.Controls.Add(this.lblMatheus);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.pictureBox3);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pbSableye)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTurtwig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatheus;
        private System.Windows.Forms.Label lblCarol;
        private System.Windows.Forms.Label lblRA2;
        private System.Windows.Forms.Label lblRA1;
        private System.Windows.Forms.Label lblRA;
        private System.Windows.Forms.PictureBox pbSableye;
        private System.Windows.Forms.Label lblClasses2;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblClasses;
        private System.Windows.Forms.Label lblLP;
        private System.Windows.Forms.Label lblClasses3;
        private System.Windows.Forms.Label lblClasses1;
        private System.Windows.Forms.Label lblCsharp;
        private System.Windows.Forms.Label lblV1;
        private System.Windows.Forms.Label lblVersao;
        private System.Windows.Forms.Label lblCopyright;
        private System.Windows.Forms.Label lblNomeApp;
        private System.Windows.Forms.PictureBox pbTurtwig;
        private System.Windows.Forms.Label lblEmpresa;
        private System.Windows.Forms.Label lblArasaka;
        private System.Windows.Forms.Label lblIntuito;
        private System.Windows.Forms.Label lblExplicacao;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}