﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482421008
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();
        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            bnFerramenta.AddNew();
            txtNome.Enabled = true;
            txtSite.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxDistribuicao.Enabled = true;
            cbxFabricante.Enabled = true;
            dtpCadastro.Enabled = true;

            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegFerr = new Ferramenta();
                RegFerr.IdFerramenta = Convert.ToInt32(txtIdFer.Text);

                if (RegFerr.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluída com sucesso!");

                    dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegFerr.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Ferramenta!");
                }
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Ferramenta Inválida!");
            }
            else if (cbxDistribuicao.SelectedIndex == -1)
            {
                MessageBox.Show("Distribuição Inválida!");
            }
            else if (txtSite.Text == "" || txtSite.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Site Inválido!");
            }
            else if (Convert.ToDateTime(dtpCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data Inválida!");
            }
            else if (cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Categoria Inválida!");
            }
            else if (cbxFabricante.SelectedIndex == -1)
            {
                MessageBox.Show("Fabricante Inválido!");
            }
            else
            {
                Ferramenta RegFerr = new Ferramenta();

                RegFerr.IdFerramenta = Convert.ToInt16(txtIdFer.Text);
                RegFerr.Nome = txtNome.Text;
                RegFerr.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFerr.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());
                RegFerr.DtCadastro = dtpCadastro.Value;
                RegFerr.SiteOficial = txtSite.Text;
                RegFerr.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());



                if (bInclusao)
                {
                    if (RegFerr.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtIdFer.Enabled = false;
                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!");
                    }
                }
                else
                {
                    RegFerr.IdFerramenta = Convert.ToInt32(txtIdFer.Text);
                    if (RegFerr.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());

                        txtIdFer.Enabled = false;
                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!");
                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

            txtNome.Enabled = true;
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;




            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;

            bInclusao = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();
            txtNome.Enabled = false;
            txtSite.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtpCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta RegFerr = new Ferramenta();
                dsFerramenta.Tables.Add(RegFerr.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtIdFer.DataBindings.Add("TEXT", bnFerramenta, "id");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSite.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                //carrega os dados da categoria
                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());

                cbxCategoria.DataSource = dsCategoria.Tables["CATEGORIA"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "Id";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idcategoria");

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());

                cbxFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                cbxFabricante.DisplayMember = "nomefantasia";
                cbxFabricante.ValueMember = "Id";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
